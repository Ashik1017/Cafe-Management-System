﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafe_Management_System
{
    public partial class Remove : Form
    {
        public Remove()
        {
            InitializeComponent();
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select Catagory,Item_Name,Price from ItemTable", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewDelete.DataSource = dt;
        }

        private void dataGridViewDelete_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewDelete.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                dataGridViewDelete.CurrentRow.Selected = true;
                textSearchItem.Text = dataGridViewDelete.Rows[e.RowIndex].Cells["Item_Name"].FormattedValue.ToString();
            }

            if (MessageBox.Show("Delete Item?", "Important Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand("delete ItemTable where Item_Name = @Item_Name", con);
                cmd.Parameters.AddWithValue("@Item_Name", textSearchItem.Text);
                cmd.ExecuteNonQuery();

                SqlCommand cd = new SqlCommand("Select Catagory,Item_Name,Price from ItemTable", con);
                SqlDataAdapter da = new SqlDataAdapter(cd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewDelete.DataSource = dt;

                con.Close();
                MessageBox.Show("Item Deleted Successfully.");
                textSearchItem.Clear();
            }
        }

        private void textSearchItem_TextChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select Catagory,Item_Name,Price from ItemTable where Item_Name = @Item_Name", con);
            cmd.Parameters.AddWithValue("@Item_Name", textSearchItem.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewDelete.DataSource = dt;
        }

        private void btnLogOut_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login fm = new Login();
            this.Hide();
            fm.Show();
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            PlaceOrder placeOrder = new PlaceOrder();
            placeOrder.Show();
            this.Hide();
        }

        private void btnAddItems_Click(object sender, EventArgs e)
        {
            Add add = new Add();
            add.Show();
            this.Hide();
        }

        private void btnUpdateItems_Click(object sender, EventArgs e)
        {
            Update update = new Update();
            update.Show();
            this.Hide();
        }
    }
}
