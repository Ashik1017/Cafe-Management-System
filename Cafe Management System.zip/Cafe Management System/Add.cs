﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafe_Management_System
{
    public partial class Add : Form
    {
        public Add()
        {
            InitializeComponent();
        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into ItemTable values (@Catagory,@Item_Name,@Price)", con);
            cmd.Parameters.AddWithValue("@Catagory", txtCatagory.Text);
            cmd.Parameters.AddWithValue("@Item_Name", txtItemName.Text);
            cmd.Parameters.AddWithValue("@Price", int.Parse(txtPrice.Text));
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Item Added Successfully");
            clearAll();
        }

        private void btnLogOut_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login fm = new Login();
            this.Hide();
            fm.Show();
        }

        private void btnRemoveItems_Click(object sender, EventArgs e)
        {
            Remove remove = new Remove();
            remove.Show();
            this.Hide();
        }

        private void btnUpdateItems_Click(object sender, EventArgs e)
        {
            Update update = new Update();
            update.Show();
            this.Hide();
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            PlaceOrder placeOrder = new PlaceOrder();
            placeOrder.Show();
            this.Hide();
        }
        public void clearAll()
        {
            txtCatagory.SelectedIndex = -1;
            txtItemName.Clear();
            txtPrice.Clear();
        }
    }
}
