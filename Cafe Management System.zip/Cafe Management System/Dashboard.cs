﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafe_Management_System
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        public Dashboard(String user)
        {
            InitializeComponent();

            if(user == "Guest")
            {
                btnAddItems.Hide();
                btnUpdateItems.Hide();
                btnRemoveItems.Hide();
                pnlPlaceOrder.Hide();
            }
            else if (user == "Admin")
            {
                pnlPlaceOrder.Hide();
            }
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {

        }

        private void btnLogOut_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from CartTable", con);
            cmd.ExecuteNonQuery();

            SqlCommand cd = new SqlCommand("Select Item_Name,Unit_Price,Quantity,Total_Price from CartTable", con);
            SqlDataAdapter da = new SqlDataAdapter(cd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewCart.DataSource = dt;

            con.Close();

            Login fm = new Login();
            this.Hide();
            fm.Show();
        }

        int num = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if(num == 0)
            {
                labelBanner.Location = new Point(24, 389);
                labelBanner.ForeColor = Color.Orange;
                num++;
            }
            else if(num == 1)
            {
                labelBanner.Location = new Point(245, 389);
                labelBanner.ForeColor = Color.Green;
                num++;
            }
            else if (num == 2)
            {
                labelBanner.Location = new Point(114, 389);
                labelBanner.ForeColor = Color.RoyalBlue;
                num = 0;
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnAddItems_Click(object sender, EventArgs e)
        {
            Add add = new Add();
            add.Show();
            this.Hide();
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            pnlWelcome.Hide();
            pnlPlaceOrder.Show();
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdateItems_Click(object sender, EventArgs e)
        {
            Update update = new Update();
            update.Show();
            this.Hide();
        }

        private void btnRemoveItems_Click(object sender, EventArgs e)
        {
            Remove remove = new Remove();
            remove.Show();
            this.Hide();
        }

        private void btnUpdateCart_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("update CartTable set Quantity = @Quantity where Item_Name=@Item_Name and Unit_Price=@Unit_Price", con);
            cmd.Parameters.AddWithValue("@Quantity", textQuantityUpDown.Text);
            cmd.Parameters.AddWithValue("@Item_Name", textItemName.Text);
            cmd.Parameters.AddWithValue("@Unit_Price", textPrice.Text);
            cmd.ExecuteNonQuery();

            SqlCommand cd = new SqlCommand("Select Item_Name,Unit_Price,Quantity,Total_Price from CartTable", con);
            SqlDataAdapter da = new SqlDataAdapter(cd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewCart.DataSource = dt;

            con.Close();
            MessageBox.Show("Cart Updated Successfully.");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from CartTable", con);
            cmd.ExecuteNonQuery();

            SqlCommand cd = new SqlCommand("Select Item_Name,Unit_Price,Quantity,Total_Price from CartTable", con);
            SqlDataAdapter da = new SqlDataAdapter(cd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewCart.DataSource = dt;

            con.Close();
            MessageBox.Show("Successfully Cleared.");
            textItemName.Clear();
            textPrice.Clear();
            textQuantityUpDown.Value = 0;
            textSearch.Clear();
            comboCatagory.SelectedIndex = -1;
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from CartTable where Item_Name=@Item_Name and Unit_Price=@Unit_Price and Quantity=@Quantity", con);
            cmd.Parameters.AddWithValue("@Item_Name", textItemName.Text);
            cmd.Parameters.AddWithValue("@Unit_Price", textPrice.Text);
            cmd.Parameters.AddWithValue("@Quantity", textQuantityUpDown.Text);
            cmd.ExecuteNonQuery();

            SqlCommand cd = new SqlCommand("Select Item_Name,Unit_Price,Quantity,Total_Price from CartTable", con);
            SqlDataAdapter da = new SqlDataAdapter(cd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewCart.DataSource = dt;

            con.Close();
            MessageBox.Show("Successfully Removed.");
            textItemName.Clear();
            textPrice.Clear();
            textQuantityUpDown.Value = 0;
        }

        private void comboCatagory_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select Item_Name,Price from ItemTable where Catagory = @Catagory", con);
            cmd.Parameters.AddWithValue("@Catagory", comboCatagory.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewSearch.DataSource = dt;
        }

        private void btnAddtoCart_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into CartTable values (@Item_Name,@Unit_Price,@Quantity,@Total_Price)", con);
            cmd.Parameters.AddWithValue("@Item_Name", textItemName.Text);
            cmd.Parameters.AddWithValue("@Unit_Price", int.Parse(textPrice.Text));
            cmd.Parameters.AddWithValue("@Quantity", int.Parse(textQuantityUpDown.Text));
            cmd.Parameters.AddWithValue("@Total_Price", int.Parse(textQuantityUpDown.Text) * int.Parse(textPrice.Text));
            cmd.ExecuteNonQuery();

            SqlCommand cd = new SqlCommand("Select Item_Name,Unit_Price,Quantity,Total_Price from CartTable", con);
            SqlDataAdapter da = new SqlDataAdapter(cd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewCart.DataSource = dt;

            con.Close();
            textSearch.Clear();
            comboCatagory.SelectedIndex = -1;
        }

        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select Item_Name,Price from ItemTable where Item_Name = @Item_Name", con);
            cmd.Parameters.AddWithValue("@Item_Name", textSearch.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewSearch.DataSource = dt;
        }

        private void dataGridViewSearch_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewSearch.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                dataGridViewSearch.CurrentRow.Selected = true;
                textItemName.Text = dataGridViewSearch.Rows[e.RowIndex].Cells["Item_Name"].FormattedValue.ToString();
                textPrice.Text = dataGridViewSearch.Rows[e.RowIndex].Cells["Price"].FormattedValue.ToString();
            }
        }

        private void dataGridViewCart_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewCart.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                dataGridViewCart.CurrentRow.Selected = true;
                textItemName.Text = dataGridViewCart.Rows[e.RowIndex].Cells["Item_Name"].FormattedValue.ToString();
            }
            if (MessageBox.Show("Delete Item?", "Important Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand("delete CartTable where Item_Name = @Item_Name", con);
                cmd.Parameters.AddWithValue("@Item_Name", textItemName.Text);
                cmd.ExecuteNonQuery();

                SqlCommand cd = new SqlCommand("Select Item_Name,Unit_Price,Quantity,Total_Price from CartTable", con);
                SqlDataAdapter da = new SqlDataAdapter(cd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewCart.DataSource = dt;

                con.Close();
                MessageBox.Show("Item Deleted Successfully.");
                textItemName.Clear();
            }
        }
    }
}
