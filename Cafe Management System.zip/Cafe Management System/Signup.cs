﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafe_Management_System
{
    public partial class Signup : Form
    {
        public Signup()
        {
            InitializeComponent();
        }

        private void btnLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtCreatePassword.Text == txtConfirmPassword.Text)
                {
                    SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");
                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into LoginTable values (@username,@password)", con);
                    cmd.Parameters.AddWithValue("@username", txtUserName.Text);
                    cmd.Parameters.AddWithValue("@password", txtCreatePassword.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("User Created Successfully");
                    clearAll();
                }
                else
                {
                    MessageBox.Show("Passwords must be same.");
                    clearAll();
                }
            }
            catch
            {
                MessageBox.Show("Username Already Exist.");
                clearAll();
            }
        }
        public void clearAll()
        {
            txtUserName.Clear();
            txtCreatePassword.Clear();
            txtConfirmPassword.Clear();
        }
    }
}
