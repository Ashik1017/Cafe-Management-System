﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafe_Management_System
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUserName.Text == "Ragnarok" && txtPassword.Text == "baiust123")
            {
                Dashboard ds = new Dashboard("Admin");
                ds.Show();
                this.Hide();
            }
            else
            {
                String username, password;

                username = txtUserName.Text;
                password = txtPassword.Text;

                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Select * from LoginTable where username = @username and password = @password", con);
                    cmd.Parameters.AddWithValue("@username", txtUserName.Text);
                    cmd.Parameters.AddWithValue("@password", txtPassword.Text);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        username = txtUserName.Text;
                        password = txtPassword.Text;

                        Dashboard ds = new Dashboard("Guest");
                        ds.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Incorrect User Name or Password");
                        clearAll();
                    }
                }
                catch
                {
                    MessageBox.Show("Error");
                }
                finally
                {
                    con.Close();
                }
            }
        }
        public void clearAll()
        {
            txtUserName.Clear();
            txtPassword.Clear();
        }

        private void btnSignup_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Signup signup = new Signup();
            signup.Show();
            this.Hide();
        }
    }
}
