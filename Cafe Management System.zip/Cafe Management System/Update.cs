﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafe_Management_System
{
    public partial class Update : Form
    {
        public Update()
        {
            InitializeComponent();
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select Catagory,Item_Name,Price from ItemTable", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewUpdate.DataSource = dt;
        }

        private void txtSearchItem_TextChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select Catagory,Item_Name,Price from ItemTable where Item_Name = @Item_Name", con);
            cmd.Parameters.AddWithValue("@Item_Name", txtSearchItem.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewUpdate.DataSource = dt;
        }

        private void dataGridViewUpdate_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewUpdate.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                dataGridViewUpdate.CurrentRow.Selected = true;
                txtUpdatedCatagory.Text = dataGridViewUpdate.Rows[e.RowIndex].Cells["Catagory"].FormattedValue.ToString();
                txtUpdatedItemName.Text = dataGridViewUpdate.Rows[e.RowIndex].Cells["Item_Name"].FormattedValue.ToString();
                txtUpdatedPrice.Text = dataGridViewUpdate.Rows[e.RowIndex].Cells["Price"].FormattedValue.ToString();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\source\\repos\\Cafe Management System\\CafeDB.mdf\";Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("update ItemTable set Price = @Price where Catagory = @Catagory and Item_Name = @Item_Name", con);
            cmd.Parameters.AddWithValue("@Catagory", txtUpdatedCatagory.Text);
            cmd.Parameters.AddWithValue("@Item_Name", txtUpdatedItemName.Text);
            cmd.Parameters.AddWithValue("@Price", int.Parse(txtUpdatedPrice.Text));
            cmd.ExecuteNonQuery();

            SqlCommand cd = new SqlCommand("Select Catagory,Item_Name,Price from ItemTable", con);
            SqlDataAdapter da = new SqlDataAdapter(cd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewUpdate.DataSource = dt;

            con.Close();
            MessageBox.Show("Item Updated Successfully.");
            txtUpdatedCatagory.Clear();
            txtUpdatedItemName.Clear();
            txtUpdatedPrice.Clear();
        }

        private void btnLogOut_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login fm = new Login();
            this.Hide();
            fm.Show();
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            PlaceOrder placeOrder = new PlaceOrder();
            placeOrder.Show();
            this.Hide();
        }

        private void btnAddItems_Click(object sender, EventArgs e)
        {
            Add add = new Add();
            add.Show();
            this.Hide();
        }

        private void btnRemoveItems_Click(object sender, EventArgs e)
        {
            Remove remove = new Remove();
            remove.Show();
            this.Hide();
        }
    }
}
